# This module implements two methods to calculate the factorial

def factI(n): #Assuming n >0 and n is int
    result = 1
    while n > 1:
        result = result * n
        n = n - 1
    return result

def factR(n):
    if n == 1:
        return n
    else:
        return n * factR(n - 1)